﻿using System;
using System.Numerics;
using System.Text;
using System.Windows.Forms;

namespace RSA_Algorithm
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Генерація простих чисел (для простоти, використовуємо невеликі значення)
                Random rnd = new Random();
                BigInteger p = GenerateRandomPrime(rnd, 5000, 10000);
                BigInteger q = GenerateRandomPrime(rnd, 5000, 10000);

                // Обчислення n і φ(n)
                BigInteger n = p * q;
                BigInteger phi = (p - 1) * (q - 1);

                // Вибір відкритого ключа e
                BigInteger e1 = GenerateCoprime(phi, rnd);

                // Обчислення закритого ключа d
                BigInteger d = ModInverse(e1, phi);

                // Перетворення повідомлення на числове значення
                byte[] messageBytes = Encoding.UTF8.GetBytes(textBox1.Text);
                BigInteger message = new BigInteger(messageBytes);

                if (message >= n)
                {
                    MessageBox.Show("Message is too large for the current key size.");
                    return;
                }

                // Підписання повідомлення
                BigInteger signature = BigInteger.ModPow(message, d, n);

                labelSign.Text = signature.ToString();
                labelKey.Text = e1.ToString();
                labelN.Text = n.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        public static BigInteger ModInverse(BigInteger a, BigInteger m)
        {
            BigInteger m0 = m, t, q;
            BigInteger x0 = 0, x1 = 1;

            if (m == 1)
                return 0;

            while (a > 1)
            {
                q = a / m;
                t = m;
                m = a % m;
                a = t;
                t = x0;
                x0 = x1 - q * x0;
                x1 = t;
            }

            if (x1 < 0)
                x1 += m0;

            return x1;
        }

        public static BigInteger GenerateRandomPrime(Random rnd, int min, int max)
        {
            BigInteger prime;
            do
            {
                prime = rnd.Next(min, max);
            } while (!IsPrime(prime));
            return prime;
        }

        public static bool IsPrime(BigInteger number)
        {
            if (number < 2) return false;
            if (number == 2 || number == 3) return true;
            if (number % 2 == 0 || number % 3 == 0) return false;

            for (BigInteger i = 5; i * i <= number; i += 6)
            {
                if (number % i == 0 || number % (i + 2) == 0)
                    return false;
            }
            return true;
        }

        public static BigInteger GenerateCoprime(BigInteger phi, Random rnd)
        {
            BigInteger e;
            do
            {
                e = rnd.Next(2, (int)phi);
            } while (BigInteger.GreatestCommonDivisor(e, phi) != 1);
            return e;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (!BigInteger.TryParse(textSign.Text, out BigInteger signature))
                {
                    MessageBox.Show("Please enter a valid number for the signature.");
                    return;
                }

                if (!BigInteger.TryParse(textKey.Text, out BigInteger e1))
                {
                    MessageBox.Show("Please enter a valid number for the key.");
                    return;
                }

                if (!BigInteger.TryParse(textN.Text, out BigInteger n))
                {
                    MessageBox.Show("Please enter a valid number for n.");
                    return;
                }

                // Перетворення оригінального повідомлення на числове значення
                byte[] originalMessageBytes = Encoding.UTF8.GetBytes(textMessage.Text);
                BigInteger originalMessage = new BigInteger(originalMessageBytes);

                // Перевірка підпису
                BigInteger verifiedMessage = BigInteger.ModPow(signature, e1, n);

                // Перетворення перевіреного повідомлення назад на рядок
                string verifiedMessageString = Encoding.UTF8.GetString(verifiedMessage.ToByteArray());

                if (textMessage.Text == verifiedMessageString.TrimEnd('\0'))
                {
                    labelVer.Text = "True";
                }
                else
                {
                    labelVer.Text = "False";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textKey.Clear();
            textN.Clear();
            textMessage.Clear();
            textSign.Clear();
            labelSign.Text = "";
            labelN.Text = "";
            labelKey.Text = "";
            labelVer.Text = "";
        }
    }
}