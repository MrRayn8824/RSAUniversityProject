﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RSA_Algorithm
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        RSAParameters publicKey;
        byte[] signedMessage;

        private void button1_Click(object sender, EventArgs e)
        {
            using (RSA rsa = RSA.Create())
            {
                RSAParameters privateKey = rsa.ExportParameters(true);
                publicKey = rsa.ExportParameters(false);

                if (textBox1.Text != "")
                {
                    string message = textBox1.Text;
                    byte[] messageBytes = Encoding.UTF8.GetBytes(message);

                    signedMessage = SignData(messageBytes, privateKey);

                    labelKey.Text = Convert.ToBase64String(publicKey.Modulus) + "|" + Convert.ToBase64String(publicKey.Exponent); ;
                }
            }
        }

        public static byte[] SignData(byte[] data, RSAParameters privateKey)
        {
            using (RSA rsa = RSA.Create())
            {
                rsa.ImportParameters(privateKey);
                return rsa.SignData(data, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            }
        }

        public static bool VerifyData(byte[] data, byte[] signedData, RSAParameters publicKey)
        {
            using (RSA rsa = RSA.Create())
            {
                rsa.ImportParameters(publicKey);
                return rsa.VerifyData(data, signedData, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(textBox2.Text != "")
            {
                string message = textBox2.Text;
                byte[] messageBytes = Encoding.UTF8.GetBytes(message);
                bool isVerified = VerifyData(messageBytes, signedMessage, publicKey);
                if (isVerified) { labelVer.Text = "True"; } else {  labelVer.Text = "False"; }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            publicKey = new RSAParameters();
        }
    }
}
